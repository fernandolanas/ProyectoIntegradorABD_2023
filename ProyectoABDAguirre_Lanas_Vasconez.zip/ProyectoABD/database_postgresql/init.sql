create table client(clientId serial, 
clientName varchar(150), 
clientLastName varchar(150), 
clientPhoneNumber varchar(150)); 